/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package edu.compensar.codigo;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.io.File;
import java.util.Random;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.Timer;
import javax.swing.border.TitledBorder;

/**
 *
 * @author USUARIO
 */
public class VentanaPrincipal extends javax.swing.JFrame {
    
    private Panel Calle;
    private JLabel lblSaldo;
    private JLabel lblUltimo;
    private JButton btnPagar;
    private JButton btnRecargar;
    private JLabel lblBono;
    private TarjetaTransmilenio tarjetaUnica;
    private transmilenio transmiSeleccionado = null;
    
    public VentanaPrincipal() {
        
        // CREAR TARJETA ÚNICA PARA TODO EL SISTEMA
        TarjetaTransmilenio.setTarjetaUnica(new TarjetaBonificada("Usuario1", 10000));
        tarjetaUnica = TarjetaTransmilenio.getTarjetaUnica();


        

        setTitle("Calle TransMilenio");
        setSize(1200, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        setLayout(new BorderLayout());

        // PANEL PRINCIPAL
        Calle = new Panel(this::actualizarPanelDerecho);
        add(Calle, BorderLayout.CENTER);

         // PANEL DERECHO
        JPanel panelDerecho = new JPanel();
        panelDerecho.setPreferredSize(new Dimension(250, 0));
        panelDerecho.setLayout(new BoxLayout(panelDerecho, BoxLayout.Y_AXIS));
        panelDerecho.setBorder(new TitledBorder("Tarjeta del Usuario"));

         lblSaldo = new JLabel("Saldo: ---");
         lblSaldo.setFont(new Font("Arial", Font.BOLD, 16));
         lblSaldo.setAlignmentX(Component.CENTER_ALIGNMENT);

         lblUltimo = new JLabel("ultimo movimiento: ---");
         lblUltimo.setAlignmentX(Component.CENTER_ALIGNMENT);

// NUEVO → etiqueta del bono
       lblBono = new JLabel("");
        lblBono.setFont(new Font("Arial", Font.BOLD, 14));
       lblBono.setForeground(Color.MAGENTA);
       lblBono.setAlignmentX(Component.CENTER_ALIGNMENT);

       btnPagar = new JButton("Pagar Pasaje");
       btnPagar.setAlignmentX(Component.CENTER_ALIGNMENT);
       btnPagar.addActionListener(e -> pagarPasaje());

      btnRecargar = new JButton("Recargar +5000");
      btnRecargar.setAlignmentX(Component.CENTER_ALIGNMENT);
      btnRecargar.addActionListener(e -> recargarTarjeta());

     panelDerecho.add(Box.createVerticalStrut(30));
     panelDerecho.add(lblSaldo);
     panelDerecho.add(Box.createVerticalStrut(10));
     panelDerecho.add(lblUltimo);
     panelDerecho.add(Box.createVerticalStrut(10));

    // NUEVO → aquí colocamos el mensaje de bono
    panelDerecho.add(lblBono);

    panelDerecho.add(Box.createVerticalStrut(20));
    panelDerecho.add(btnPagar);
    panelDerecho.add(Box.createVerticalStrut(10));
    panelDerecho.add(btnRecargar);

       add(panelDerecho, BorderLayout.EAST);
        
        // TIMER PARA AGREGAR BUSES
        Timer timer = new Timer(3000, null);
        Random rand = new Random();
        final int[] contador = {0};

        timer.addActionListener(e -> {
            if (contador[0] >= 4) {
                timer.stop();
                return;
            }

            int yCarretera = Calle.getHeight() / 7;
            int carreteraInicio = yCarretera - 40;
            int carreteraFin = carreteraInicio + 660;

            int x = -200;
            int y = rand.nextInt((carreteraFin - 60) - carreteraInicio) + carreteraInicio;

            int vx = rand.nextInt(3) + 2;

           boolean esAzul = rand.nextBoolean(); // true o false al azar

          Calle.agregarCriatura(
           new Transmi(x, y, vx, 0, esAzul, !esAzul, 0, 0)
         );

        });

        timer.start();
    }
      
 // ACTUALIZA LA INFORMACIÓN DE LA TARJETA AL TOCAR UN BUS
    private void actualizarPanelDerecho(transmilenio t) {

    if (t != null) {
        transmiSeleccionado = t;

        lblSaldo.setText("Saldo: $" + tarjetaUnica.getSaldo());
        lblUltimo.setText("Último movimiento: Seleccionado");

        if (tarjetaUnica instanceof TarjetaBonificada) {
            lblBono.setText(((TarjetaBonificada) tarjetaUnica).getMensajeBono());
        }

    } else {
        transmiSeleccionado = null;
        lblSaldo.setText("Saldo: ---");
        lblUltimo.setText("Último movimiento: ---");
        lblBono.setText("");
    }
}
    
    private void pagarPasaje() {
    if (transmiSeleccionado == null) return;

    tarjetaUnica.pagarPasaje();

    lblSaldo.setText("Saldo: $" + tarjetaUnica.getSaldo());
    lblUltimo.setText("Último movimiento: Pago de pasaje");

    if (tarjetaUnica instanceof TarjetaBonificada) {
        lblBono.setText(((TarjetaBonificada) tarjetaUnica).getMensajeBono());
    }

    reproducirSonido(); // <<< así se llama ahora
}



    
    // BOTÓN: RECARGAR TARJETA
   private void recargarTarjeta() {
    if (transmiSeleccionado == null) return;

    tarjetaUnica.recargar(5000);

    lblSaldo.setText("Saldo: $" + tarjetaUnica.getSaldo());
    lblUltimo.setText("Último movimiento: Recarga +5000");
}
   
   private void reproducirSonido() {
     try {
        var url = getClass().getResource("/edu/compensar/codigo/sonido/Pagar.wav");

        if (url == null) {
            System.out.println("No se encontró el archivo Pagar.wav");
            return;
        }

        AudioInputStream audio = AudioSystem.getAudioInputStream(url);
        Clip clip = AudioSystem.getClip();
        clip.open(audio);
        clip.start();

    } catch (Exception e) {
        e.printStackTrace();
    }
    
}
   
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VentanaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VentanaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VentanaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VentanaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new VentanaPrincipal().setVisible(true);
            }
        });
    }
   
}


    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables

