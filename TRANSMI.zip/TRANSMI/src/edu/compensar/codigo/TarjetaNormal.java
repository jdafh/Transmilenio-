
package edu.compensar.codigo;

/**
 *
 * @author USUARIO
 */
public class TarjetaNormal extends TarjetaTransmilenio {

    public int viajesRealizados;

    public TarjetaNormal(String idUsuario, double saldo) {
        super(idUsuario, saldo);
        this.viajesRealizados = 0;
    }

    @Override
    public void pagarPasaje() {
        double valorPasaje = 2950;

        if (saldo >= valorPasaje) {
            saldo -= valorPasaje;
            viajesRealizados++;
            System.out.println("Pasaje pagado. Viajes: " + viajesRealizados);
        } else {
            System.out.println("Saldo insuficiente.");
        }
    }

    public int getViajesRealizados() {
        return viajesRealizados;
    }
}
