/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package edu.compensar.codigo;

/**
 *
 * @author USUARIO
 */
public interface Interactivo {
    
    void seleccionar();

    void deseleccionar();

    boolean estaSeleccionado();

    boolean contienePunto(int px, int py);
}
