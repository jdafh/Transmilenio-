/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.compensar.codigo;

/**
 *
 * @author USUARIO
 */
public abstract class TarjetaTransmilenio {

    protected String idUsuario;
    protected double saldo;

    // TARJETA ÚNICA DEL SISTEMA
    private static TarjetaTransmilenio unica;

    public static TarjetaTransmilenio getTarjetaUnica() {
        return unica;
    }

    // ESTE LO AGREGAS ↓↓↓↓↓
    public static void setTarjetaUnica(TarjetaTransmilenio t) {
        unica = t;
    }

    public TarjetaTransmilenio(String idUsuario, double saldo) {
        this.idUsuario = idUsuario;
        this.saldo = saldo;
    }

    public abstract void pagarPasaje();

    public void recargar(double monto) {
        if (monto > 0) {
            saldo += monto;
            System.out.println("Se recargaron $" + monto + ". Saldo actual: $" + saldo);
        } else {
            System.out.println("Monto inválido para recarga.");
        }
    }

    public String getIdUsuario() {
        return idUsuario;
    }

    public double getSaldo() {
        return saldo;
    }
}


