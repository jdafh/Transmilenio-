/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.compensar.codigo;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;

/**
 *
 * @author USUARIO
 */
public class Transmi extends transmilenio {

    private Color colorBus;
    private TarjetaTransmilenio tarjeta; 

 
    public Transmi(int x, int y, int velocidadX, int velocidadY, boolean azul,boolean rojo, int ancho, int alto) {
        super(x, y, velocidadX, velocidadY, 50, 0);

        
        this.colorBus = azul ? Color.BLUE : Color.RED;
    }
    

   
    public void setTarjeta(TarjetaTransmilenio tarjeta) {
        this.tarjeta = tarjeta;
    }

    @Override
    public void dibujar(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;

        int anchoBus = 160;
        int altoBus = 60;

        // Cuerpo del bus
        g.setColor(colorBus);
        g.fillRect(x, y, anchoBus, altoBus);

        // Ventanas
        g.setColor(Color.CYAN);
        g.fillRect(x + 15, y + 10, 30, 25);
        g.fillRect(x + 55, y + 10, 30, 25);
        g.fillRect(x + 95, y + 10, 30, 25);

        // Puerta
        g.setColor(Color.LIGHT_GRAY);
        g.fillRect(x + 135, y + 10, 20, 40);

        // Llantas
        g.setColor(Color.BLACK);
        g.fillOval(x + 25, y + altoBus - 15, 25, 25);
        g.fillOval(x + 110, y + altoBus - 15, 25, 25);

        // Selección
        if (estaSeleccionado()) {
            g2d.setColor(Color.CYAN);
            g2d.setStroke(new BasicStroke(3));
            g2d.drawRect(x, y, anchoBus, altoBus);
        }
    }

    @Override
    public String getValorPasaje() {
        return "2950";
    }
}


 



     
    


    
