/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.compensar.codigo;

/**
 *
 * @author USUARIO
 */
public class TarjetaBonificada extends TarjetaNormal {

    private String mensajeBono = ""; // ← nuevo

    public TarjetaBonificada(String idUsuario, double saldo) {
        super(idUsuario, saldo);
    }

    @Override
    public void pagarPasaje() {
        super.pagarPasaje();
        aplicarBono();
    }

    private void aplicarBono() {
        if (viajesRealizados == 5) {
            saldo += 1000;
            mensajeBono = "<html>Bono aplicado:<br>$1000 por 5 viajes</html>";

            System.out.println(mensajeBono);
        } else if (viajesRealizados == 10) {
            saldo += 3000;
            mensajeBono = "<html>Bono aplicado:<br>$3000 por 10 viajes</html>";
            System.out.println(mensajeBono);
            viajesRealizados = 0;
        } else {
            mensajeBono = ""; // si no hay bono, limpiamos
        }
    }

    public String getMensajeBono() {
        return mensajeBono;
    }
}