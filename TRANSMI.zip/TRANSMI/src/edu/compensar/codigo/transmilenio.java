/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.compensar.codigo;

import java.awt.Graphics;
import java.awt.Rectangle;

/**
 *
 * @author USUARIO
 */
public abstract class transmilenio implements Interactivo{
     
    protected int x, y;
    protected int velocidadX, velocidadY;
    protected int ancho, alto;
    protected boolean seleccionado;

    public transmilenio(int x, int y, int velocidadX, int velocidadY, int ancho, int alto) {
        this.x = x;
        this.y = y;
        this.velocidadX = velocidadX;
        this.velocidadY = velocidadY;
        this.ancho = 160;
        this.alto = 60;
        this.seleccionado = false;
    }
     public abstract void dibujar(Graphics g);

    public abstract String getValorPasaje();

   public void mover(int limiteAncho, int limiteAlto) {
    // Solo se mueve horizontal
    x += velocidadX;

    // Si sale por la derecha, vuelve a entrar por la izquierda
    if (x > limiteAncho) {
        x = -ancho;
    }

    // (Opcional) si quieres que también funcione al revés:
    if (x < -ancho) {
        x = limiteAncho;
    }

    
}



    @Override
    public void seleccionar() {
        this.seleccionado = true;
    }

    
    @Override
    public void deseleccionar() {
        this.seleccionado = false;
    }

    
    @Override
    public boolean estaSeleccionado() {
        return seleccionado;
    }


    @Override
    public boolean contienePunto(int px, int py) {
        Rectangle bounds = new Rectangle(x, y, alto, ancho);
        return bounds.contains(px, py);
    }  


}
